package com.example.demo;

public class Parametro {
	
	private String nombre;
	private String tipo;
	private String valor;
	private Indicador indicador;
	
	
	public Parametro(String nombre, String tipo, String valor) {
		super();
		this.nombre = nombre;
		this.tipo = tipo;
		this.valor = valor;
		this.indicador = null;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public Indicador getIndicador() {
		return indicador;
	}
	public void setIndicador(Indicador indicador) {
		this.indicador = indicador;
	}
		
public boolean validar() {
		
		boolean valido = false;
		
		if(this.getNombre().equals("")) {
			System.out.println("El nombre del parámetro " + nombre + " es válido");
			valido = false;
			return valido;
			// Falta nombre
		}
		else if(this.getTipo() == null) {
			System.out.println("El tipo del parámetro " + nombre + "/" + tipo + " no es válido");
			valido = false;
			return valido;
			// Falta descripcion
		}
		else if(this.getValor() == null) {
			System.out.println("El valor del parámetro " + nombre + "/" + valor + " no es válido");
			valido = false;
			return valido;
			// Falta descripcion
		}
		
		else {
			valido = true;
		}
		
		return valido;
	}

}
