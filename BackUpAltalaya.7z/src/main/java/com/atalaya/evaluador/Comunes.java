package com.atalaya.evaluador;

public class Comunes {
	public static int tpIndErroneo = -1;
	public static int tpNoIndicador = 0;
	public static int tpIndicador	= 1;
	public static int tpValor	= 2;	
	public static int tpVlNoTipo = 0;
	public static int tpVlBoolean = 1;
	public static int tpVlString = 2;
	public static int tpVlInt = 3;
	public static int tpVlDate = 4;
	public static int tpVlIndicador = 5;
	public static String verdadero = "TRUE";
	public static String falso = "FALSE";
	public static String comillas = "" + (char) 34;	
}
